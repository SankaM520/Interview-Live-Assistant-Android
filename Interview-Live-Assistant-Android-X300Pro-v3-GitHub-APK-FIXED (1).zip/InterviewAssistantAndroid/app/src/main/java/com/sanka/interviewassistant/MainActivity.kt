package com.sanka.interviewassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*
import java.util.Locale

class MainActivity : AppCompatActivity() {
    private lateinit var transcript: TextView
    private lateinit var answer: TextView
    private lateinit var company: EditText
    private lateinit var position: EditText
    private lateinit var status: TextView
    private lateinit var prefs: SharedPreferences
    private var recognizer: SpeechRecognizer? = null
    private var listening = false
    private var buffer = StringBuilder()
    private var partial = ""
    private var apiKey = ""
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startListening() else status.text = "Microphone permission is required."
    }
    private val filePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) contentResolver.openInputStream(uri)?.use { input ->
            Storage.cv(this).outputStream().use { out -> input.copyTo(out) }
            status.text = "CV saved locally."
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        apiKey = prefs.getString("api_key", "") ?: ""
        buildUi()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun edit(hint: String) = EditText(this).apply { this.hint = hint; setSingleLine(true) }
        company = edit("Company (optional)")
        position = edit("Position (optional — default: General Accounting / Finance Interview)")
        val key = edit("OpenAI API key")
        key.setText(apiKey)
        content.addView(TextView(this).apply { text = "Interview Live Assistant"; textSize = 24f })
        content.addView(company); content.addView(position); content.addView(key)
        val saveKey = Button(this).apply { text = "SAVE API KEY"; setOnClickListener { apiKey = key.text.toString().trim(); prefs.edit().putString("api_key",apiKey).apply(); status.text="API key saved." } }
        val cv = Button(this).apply { text = "CHOOSE CV PDF"; setOnClickListener { filePicker.launch(arrayOf("application/pdf")) } }
        content.addView(saveKey); content.addView(cv)
        status = TextView(this).apply { text = "Ready — use speakerphone for normal calls."; textSize = 14f }
        content.addView(status)
        content.addView(TextView(this).apply { text="LIVE TRANSCRIPT"; textSize=18f })
        transcript = TextView(this).apply { text=""; textSize=17f; setPadding(8,8,8,16) }
        content.addView(transcript)
        val start = Button(this).apply { text="START LISTENING"; setOnClickListener { ensureMic() } }
        val get = Button(this).apply { text="GET ANSWER"; setOnClickListener { generateAnswer() } }
        val stop = Button(this).apply { text="STOP"; setOnClickListener { stopListening() } }
        val clear = Button(this).apply { text="CLEAR"; setOnClickListener { buffer.setLength(0); partial=""; transcript.text=""; answer.text="" } }
        content.addView(start); content.addView(get); content.addView(stop); content.addView(clear)
        content.addView(TextView(this).apply { text="ANSWER"; textSize=18f })
        answer = TextView(this).apply { textSize=18f; setPadding(8,8,8,24) }
        content.addView(answer)
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }

    private fun ensureMic() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) startListening()
        else micPermission.launch(Manifest.permission.RECORD_AUDIO)
    }

    private fun startListening() {
        if (listening) return
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text="Speech recognition is not available on this phone."; return }
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).also { r ->
            r.setRecognitionListener(object: RecognitionListener {
                override fun onReadyForSpeech(p0: Bundle?) { status.text="Listening… use speakerphone." }
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(p0: Float) {}
                override fun onBufferReceived(p0: ByteArray?) {}
                override fun onEndOfSpeech() { if (listening) restartRecognition() }
                override fun onError(error: Int) { if (listening) restartRecognition() }
                override fun onResults(results: Bundle?) {
                    val s = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty().trim()
                    if (s.isNotEmpty()) { if (buffer.isNotEmpty()) buffer.append(" "); buffer.append(s); render() }
                    if (listening) restartRecognition()
                }
                override fun onPartialResults(results: Bundle?) {
                    partial = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull().orEmpty(); render()
                }
                override fun onEvent(p0: Int, p1: Bundle?) {}
            })
        }
        listening = true; restartRecognition()
    }

    private fun restartRecognition() {
        if (!listening) return
        try { recognizer?.cancel(); val i=Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply { putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL,RecognizerIntent.LANGUAGE_MODEL_FREE_FORM); putExtra(RecognizerIntent.EXTRA_LANGUAGE,Locale.US.toLanguageTag()); putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS,true); putExtra(RecognizerIntent.EXTRA_MAX_RESULTS,1) }; recognizer?.startListening(i) } catch (_: Exception) {}
    }
    private fun render() { transcript.text = (buffer.toString() + if(partial.isNotBlank()) " $partial" else "").trim() }
    private fun stopListening() { listening=false; recognizer?.cancel(); status.text="Stopped." }

    private fun generateAnswer() {
        val q = buffer.toString().trim()
        if (q.isBlank()) { status.text="No transcript yet."; return }
        if (apiKey.isBlank()) { status.text="Save your OpenAI API key first."; return }
        buffer.setLength(0); partial=""; transcript.text=""; status.text="Generating answer…"
        val c=company.text.toString().trim(); val p=position.text.toString().trim().ifBlank { "General Accounting / Finance Interview" }
        val old = Storage.answers(this).takeIf { it.exists() }?.readText()?.takeLast(7000).orEmpty()
        val prompt = """
You are a live interview answer assistant. Return ONLY the answer the candidate should say aloud.
Candidate context: use only facts explicitly present in the local CV or saved answers when claiming personal experience. Never invent employers, clients, software, responsibilities, qualifications or results.
Company: ${c.ifBlank { "Not specified" }}
Position: $p
Current interview speech/transcript (use as the question/input; do not rewrite it): $q
Previous saved answers (use only if relevant): $old
Rules: natural spoken English; direct and professional; no essay; no headings; no meta-commentary. For 'tell me about yourself', 'tell me about your experience', or 'walk me through your CV', give a stronger structured 45-75 second introduction using relevant CV facts. For experience questions, if direct experience is not supported, say so naturally and connect only to genuinely similar/transferable experience. For behavioral questions use a concise Situation-Action-Result flow. For technical questions answer from accounting/finance knowledge without pretending it is personal experience. Keep simple questions short. Do not mention unrelated CV details.
""".trimIndent()
        scope.launch(Dispatchers.IO) {
            try {
                val a=ApiClient(apiKey).answer(prompt)
                withContext(Dispatchers.Main) { answer.text=a; status.text="Answer ready."; Storage.appendAnswer(this@MainActivity,q,a) }
            } catch(e: Exception) { withContext(Dispatchers.Main) { status.text="Answer error: ${e.message}" } }
        }
    }
    override fun onDestroy(){ stopListening(); recognizer?.destroy(); scope.cancel(); super.onDestroy() }
}
