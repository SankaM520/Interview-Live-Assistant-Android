package com.sanka.interviewassistant
import android.app.Service
import android.content.Intent
import android.os.IBinder
class MicService: Service(){ override fun onBind(intent: Intent?): IBinder?=null }
