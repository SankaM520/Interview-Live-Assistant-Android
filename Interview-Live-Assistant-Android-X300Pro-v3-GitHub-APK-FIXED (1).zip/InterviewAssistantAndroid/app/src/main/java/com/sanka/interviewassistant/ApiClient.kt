package com.sanka.interviewassistant

import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.util.concurrent.TimeUnit

class ApiClient(private val apiKey: String) {
    private val client = OkHttpClient.Builder().callTimeout(25, TimeUnit.SECONDS).build()
    fun answer(prompt: String): String {
        val body = JSONObject().apply {
            put("model", "gpt-5.6-luna")
            put("reasoning", JSONObject().put("effort", "none"))
            put("input", JSONArray().put(JSONObject().apply {
                put("role", "user"); put("content", JSONArray().put(JSONObject().put("type", "input_text").put("text", prompt)))
            }))
        }
        val req = Request.Builder().url("https://api.openai.com/v1/responses")
            .addHeader("Authorization", "Bearer $apiKey").addHeader("Content-Type", "application/json")
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use { r ->
            val text = r.body?.string().orEmpty()
            if (!r.isSuccessful) error("API ${r.code}: $text")
            val o = JSONObject(text)
            if (o.has("output_text")) return o.getString("output_text")
            val out = o.optJSONArray("output") ?: return text
            val sb = StringBuilder()
            for (i in 0 until out.length()) {
                val c = out.getJSONObject(i).optJSONArray("content") ?: continue
                for (j in 0 until c.length()) sb.append(c.getJSONObject(j).optString("text"))
            }
            return sb.toString().trim()
        }
    }
}
