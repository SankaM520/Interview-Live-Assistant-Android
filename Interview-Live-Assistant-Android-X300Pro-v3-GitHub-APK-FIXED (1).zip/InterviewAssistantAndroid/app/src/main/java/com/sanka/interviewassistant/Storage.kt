package com.sanka.interviewassistant

import android.content.Context
import java.io.File

object Storage {
    fun dir(c: Context) = File(c.filesDir, "interview-data").also { it.mkdirs() }
    fun cv(c: Context) = File(dir(c), "CV.pdf")
    fun job(c: Context) = File(dir(c), "Job-Details.txt")
    fun answers(c: Context) = File(dir(c), "Previous-Answers.txt")
    fun appendAnswer(c: Context, q: String, a: String) {
        answers(c).appendText("\n\nQUESTION:\n$q\nANSWER:\n$a\n")
    }
}
