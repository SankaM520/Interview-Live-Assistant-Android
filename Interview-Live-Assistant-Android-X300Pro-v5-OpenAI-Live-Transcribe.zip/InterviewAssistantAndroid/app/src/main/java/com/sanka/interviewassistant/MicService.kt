package com.sanka.interviewassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Intent
import android.media.AudioFormat
import android.media.AudioRecord
import android.media.MediaRecorder
import android.os.Build
import android.os.IBinder
import android.util.Base64
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.Response
import okhttp3.WebSocket
import okhttp3.WebSocketListener
import org.json.JSONObject
import java.nio.ByteBuffer
import java.nio.ByteOrder
import java.util.concurrent.TimeUnit

class MicService : Service() {
    companion object {
        const val ACTION_START = "com.sanka.interviewassistant.START"
        const val ACTION_STOP = "com.sanka.interviewassistant.STOP"
        const val ACTION_CLEAR = "com.sanka.interviewassistant.CLEAR"
        const val EXTRA_API_KEY = "api_key"
        const val BROADCAST = "com.sanka.interviewassistant.TRANSCRIPT"
        const val EXTRA_TEXT = "text"
        const val EXTRA_STATUS = "status"
        const val EXTRA_ERROR = "error"
        private const val CHANNEL_ID = "interview_assistant_mic"
        private const val NOTIFICATION_ID = 1001
    }

    private var running = false
    private var audioRecord: AudioRecord? = null
    private var audioThread: Thread? = null
    private var webSocket: WebSocket? = null
    private var transcript = StringBuilder()
    private var socketReady = false

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_START -> startCapture(intent.getStringExtra(EXTRA_API_KEY).orEmpty())
            ACTION_STOP -> stopCapture()
            ACTION_CLEAR -> {
                transcript.setLength(0)
                broadcast(text = "", status = "Transcript cleared.")
            }
        }
        return START_NOT_STICKY
    }

    private fun startCapture(apiKey: String) {
        if (running) return
        if (apiKey.isBlank()) {
            broadcast(status = "Save your OpenAI API key first.", error = true)
            stopSelf()
            return
        }

        startForeground(NOTIFICATION_ID, buildNotification("Interview assistant is listening"))
        running = true
        transcript.setLength(0)
        broadcast(status = "Connecting to OpenAI…")

        val request = Request.Builder()
            .url("wss://api.openai.com/v1/realtime?intent=transcription")
            .addHeader("Authorization", "Bearer $apiKey")
            .build()

        val client = OkHttpClient.Builder()
            .readTimeout(0, TimeUnit.MILLISECONDS)
            .build()

        webSocket = client.newWebSocket(request, object : WebSocketListener() {
            override fun onOpen(ws: WebSocket, response: Response) {
                socketReady = true
                val session = JSONObject().apply {
                    put("type", "transcription")
                    put("audio", JSONObject().apply {
                        put("input", JSONObject().apply {
                            put("format", JSONObject().apply {
                                put("type", "audio/pcm")
                                put("rate", 24000)
                            })
                            put("transcription", JSONObject().apply {
                                put("model", "gpt-live-transcribe")
                                put("language", "en")
                                put("prompt", "Spoken English accounting and finance job interview. Transcribe the interviewer's question accurately and preserve accounting, finance, company, software, and professional terms.")
                            })
                        })
                    })
                }
                ws.send(JSONObject().put("type", "session.update").put("session", session).toString())
                broadcast(status = "Listening… keep the phone on speakerphone.")
                startAudioRecord()
            }

            override fun onMessage(ws: WebSocket, text: String) {
                try {
                    val o = JSONObject(text)
                    when (o.optString("type")) {
                        "conversation.item.input_audio_transcription.delta" -> {
                            val d = o.optString("delta")
                            if (d.isNotBlank()) {
                                transcript.append(d)
                                broadcast(text = transcript.toString(), status = "Listening…")
                            }
                        }
                        "conversation.item.input_audio_transcription.completed" -> {
                            broadcast(text = transcript.toString(), status = "Listening…")
                        }
                        "error" -> {
                            val msg = o.optJSONObject("error")?.optString("message").orEmpty()
                            broadcast(status = if (msg.isBlank()) "OpenAI transcription error." else msg, error = true)
                        }
                    }
                } catch (_: Exception) {
                    // Ignore non-JSON websocket frames.
                }
            }

            override fun onFailure(ws: WebSocket, t: Throwable, response: Response?) {
                socketReady = false
                broadcast(status = "Transcription connection failed: ${t.message ?: "unknown error"}", error = true)
                stopCapture()
            }

            override fun onClosed(ws: WebSocket, code: Int, reason: String) {
                socketReady = false
            }
        })
    }

    private fun startAudioRecord() {
        if (!running || audioRecord != null) return
        val min = AudioRecord.getMinBufferSize(
            24000,
            AudioFormat.CHANNEL_IN_MONO,
            AudioFormat.ENCODING_PCM_16BIT
        )
        if (min <= 0) {
            broadcast(status = "This phone cannot open the microphone for PCM audio.", error = true)
            stopCapture()
            return
        }
        val size = maxOf(min * 2, 4096)
        try {
            audioRecord = AudioRecord(
                MediaRecorder.AudioSource.MIC,
                24000,
                AudioFormat.CHANNEL_IN_MONO,
                AudioFormat.ENCODING_PCM_16BIT,
                size
            )
            audioRecord?.startRecording()
        } catch (e: Exception) {
            broadcast(status = "Microphone start failed: ${e.message ?: "unknown error"}", error = true)
            stopCapture()
            return
        }

        audioThread = Thread {
            val buffer = ByteArray(4096)
            while (running) {
                val n = try { audioRecord?.read(buffer, 0, buffer.size) ?: -1 } catch (_: Exception) { -1 }
                if (n > 0 && socketReady) {
                    val payload = Base64.encodeToString(buffer.copyOf(n), Base64.NO_WRAP)
                    webSocket?.send(JSONObject().put("type", "input_audio_buffer.append").put("audio", payload).toString())
                }
            }
        }.apply {
            name = "InterviewAudioCapture"
            start()
        }
    }

    private fun stopCapture() {
        if (!running && audioRecord == null && webSocket == null) {
            stopSelf()
            return
        }
        running = false
        socketReady = false
        try { audioRecord?.stop() } catch (_: Exception) {}
        try { audioRecord?.release() } catch (_: Exception) {}
        audioRecord = null
        audioThread = null
        webSocket?.close(1000, "Stopped")
        webSocket = null
        broadcast(status = "Stopped.")
        stopForeground(STOP_FOREGROUND_REMOVE)
        stopSelf()
    }

    private fun broadcast(text: String? = null, status: String? = null, error: Boolean = false) {
        val i = Intent(BROADCAST).setPackage(packageName)
        if (text != null) i.putExtra(EXTRA_TEXT, text)
        if (status != null) i.putExtra(EXTRA_STATUS, status)
        i.putExtra(EXTRA_ERROR, error)
        sendBroadcast(i)
    }

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(NotificationChannel(CHANNEL_ID, "Interview Assistant", NotificationManager.IMPORTANCE_LOW))
        }
    }

    private fun buildNotification(text: String): Notification {
        return if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            Notification.Builder(this, CHANNEL_ID)
                .setContentTitle("Interview Live Assistant")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        } else {
            Notification.Builder(this)
                .setContentTitle("Interview Live Assistant")
                .setContentText(text)
                .setSmallIcon(android.R.drawable.ic_btn_speak_now)
                .setOngoing(true)
                .build()
        }
    }

    override fun onDestroy() {
        stopCapture()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?): IBinder? = null
}
