package com.sanka.interviewassistant

import android.Manifest
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import android.content.SharedPreferences
import android.content.pm.PackageManager
import android.os.Build
import android.os.Bundle
import android.widget.*
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import kotlinx.coroutines.*

class MainActivity : AppCompatActivity() {
    private lateinit var transcript: TextView
    private lateinit var answer: TextView
    private lateinit var company: EditText
    private lateinit var position: EditText
    private lateinit var status: TextView
    private lateinit var prefs: SharedPreferences
    private var apiKey = ""
    private var transcriptText = ""
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    private val micPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) startMicService() else status.text = "Microphone permission is required."
    }
    private val notificationPermission = registerForActivityResult(ActivityResultContracts.RequestPermission()) { startMicAfterNotificationCheck() }
    private val filePicker = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) contentResolver.openInputStream(uri)?.use { input ->
            Storage.cv(this).outputStream().use { out -> input.copyTo(out) }
            status.text = "CV saved locally."
        }
    }

    private val receiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context?, intent: Intent?) {
            intent.getStringExtra(MicService.EXTRA_TEXT)?.let {
                transcriptText = it
                transcript.text = it
            }
            intent.getStringExtra(MicService.EXTRA_STATUS)?.let { status.text = it }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        prefs = getSharedPreferences("settings", MODE_PRIVATE)
        apiKey = prefs.getString("api_key", "") ?: ""
        buildUi()
    }

    override fun onStart() {
        super.onStart()
        val filter = IntentFilter(MicService.BROADCAST)
        ContextCompat.registerReceiver(this, receiver, filter, ContextCompat.RECEIVER_NOT_EXPORTED)
    }

    override fun onStop() {
        try { unregisterReceiver(receiver) } catch (_: Exception) {}
        super.onStop()
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(24,24,24,24) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        fun edit(hint: String) = EditText(this).apply { this.hint = hint; setSingleLine(true) }
        company = edit("Company (optional)")
        position = edit("Position (optional — default: General Accounting / Finance Interview)")
        val key = edit("OpenAI API key")
        key.setText(apiKey)
        content.addView(TextView(this).apply { text = "Interview Live Assistant"; textSize = 24f })
        content.addView(TextView(this).apply { text = "Direct microphone → OpenAI Live Transcribe"; textSize = 14f })
        content.addView(company); content.addView(position); content.addView(key)
        val saveKey = Button(this).apply { text = "SAVE API KEY"; setOnClickListener { apiKey = key.text.toString().trim(); prefs.edit().putString("api_key",apiKey).apply(); status.text="API key saved." } }
        val cv = Button(this).apply { text = "CHOOSE CV PDF"; setOnClickListener { filePicker.launch(arrayOf("application/pdf")) } }
        content.addView(saveKey); content.addView(cv)
        status = TextView(this).apply { text = "Ready — use speakerphone for normal calls."; textSize = 14f }
        content.addView(status)
        content.addView(TextView(this).apply { text="LIVE TRANSCRIPT"; textSize=18f })
        transcript = TextView(this).apply { text=""; textSize=17f; setPadding(8,8,8,16) }
        content.addView(transcript)
        val start = Button(this).apply { text="START LISTENING"; setOnClickListener { ensurePermissionsAndStart() } }
        val get = Button(this).apply { text="GET ANSWER"; setOnClickListener { generateAnswer() } }
        val stop = Button(this).apply { text="STOP"; setOnClickListener { stopMicService() } }
        val clear = Button(this).apply { text="CLEAR"; setOnClickListener { transcriptText=""; transcript.text=""; answer.text=""; sendServiceAction(MicService.ACTION_CLEAR) } }
        content.addView(start); content.addView(get); content.addView(stop); content.addView(clear)
        content.addView(TextView(this).apply { text="ANSWER"; textSize=18f })
        answer = TextView(this).apply { textSize=18f; setPadding(8,8,8,24) }
        content.addView(answer)
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }

    private fun ensurePermissionsAndStart() {
        if (apiKey.isBlank()) { status.text = "Save your OpenAI API key first."; return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            micPermission.launch(Manifest.permission.RECORD_AUDIO)
            return
        }
        startMicAfterNotificationCheck()
    }

    private fun startMicAfterNotificationCheck() {
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            notificationPermission.launch(Manifest.permission.POST_NOTIFICATIONS)
        } else {
            startMicService()
        }
    }

    private fun startMicService() {
        val i = Intent(this, MicService::class.java).apply {
            action = MicService.ACTION_START
            putExtra(MicService.EXTRA_API_KEY, apiKey)
        }
        ContextCompat.startForegroundService(this, i)
    }

    private fun stopMicService() = sendServiceAction(MicService.ACTION_STOP)

    private fun sendServiceAction(action: String) {
        startService(Intent(this, MicService::class.java).setAction(action))
    }

    private fun generateAnswer() {
        val q = transcriptText.trim()
        if (q.isBlank()) { status.text="No transcript yet."; return }
        if (apiKey.isBlank()) { status.text="Save your OpenAI API key first."; return }
        val c=company.text.toString().trim(); val p=position.text.toString().trim().ifBlank { "General Accounting / Finance Interview" }
        val old = Storage.answers(this).takeIf { it.exists() }?.readText()?.takeLast(7000).orEmpty()
        val prompt = """
You are a live interview answer assistant. Return ONLY the answer the candidate should say aloud.
Candidate context: use only facts explicitly present in the local CV or saved answers when claiming personal experience. Never invent employers, clients, software, responsibilities, qualifications or results.
Company: ${c.ifBlank { "Not specified" }}
Position: $p
Current interview speech/transcript (use as the question/input; do not rewrite it): $q
Previous saved answers (use only if relevant): $old
Rules: natural spoken English; direct and professional; no essay; no headings; no meta-commentary. For 'tell me about yourself', 'tell me about your experience', or 'walk me through your CV', give a stronger structured 45-75 second introduction using relevant CV facts. For experience questions, if direct experience is not supported, say so naturally and connect only to genuinely similar/transferable experience. For behavioral questions use a concise Situation-Action-Result flow. For technical questions answer from accounting/finance knowledge without pretending it is personal experience. Keep simple questions short. Do not mention unrelated CV details.
""".trimIndent()
        status.text="Generating answer…"
        scope.launch(Dispatchers.IO) {
            try {
                val a=ApiClient(apiKey).answer(prompt)
                withContext(Dispatchers.Main) { answer.text=a; status.text="Answer ready."; Storage.appendAnswer(this@MainActivity,q,a) }
            } catch(e: Exception) { withContext(Dispatchers.Main) { status.text="Answer error: ${e.message}" } }
        }
    }

    override fun onDestroy(){ scope.cancel(); super.onDestroy() }
}
